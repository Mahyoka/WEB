<%-- 
    Document   : createAccount
    Created on : Oct 19, 2026, 1:33:32 PM
    Author     : admin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Create Account</title>
    </head>
    <body>
       <!-- validation 
        1.Detect Errors: 03 username, passworrd, fullname is out of range
        04: password is not matched confirm
        05: username/PK is duplicated
        2. Classify Errors: Users vs. System
        Users: 01 - 04,
        System:05
        3. Process Errors:
        User: Store in attribute, then show
        System: write log file
        -->
        <h1>Create New Account</h1>
        <form action="MainController" method="POST">
            <c:set var="errors" value="${requestScope.CREATE_ERROR}"/>
            Username* <input type="text" name="txtUsername" value="${param.txtUsername}" /> (6 - 30 chars)<br/> <!-- rang buoc -->
            <c:if test="${not empty errors.usernameOutOfRanger}">
                <font color="red">
                ${errors.usernameOutOfRanger}
                </font><br/>
            </c:if>
            Password* <input type="password" name="txtPassword" value="" /> (6 - 20 chars)<br/>
            <c:if test="${not empty errors.passwordOutOfRanger}">
                <font color="red">
                ${errors.passwordOutOfRanger}
                </font><br/>
            </c:if>
            Confirm* <input type="password" name="txtConfirm" value="" /><br/>
            <c:if test="${not empty errors.confirmNotMatched}">
                <font color="red">
                ${errors.confirmNotMatched}
                </font><br/>
            </c:if>
                Full name* <input type="text" name="txtFullName" value="${param.txtFullName}" /> (2 - 50 chars)<br/>
            <c:if test="${not empty errors.fullNameOutOfRanger}">
                <font color="red">
                ${errors.fullNameOutOfRanger}
                </font><br/>
            </c:if>
<!--            Password* <input type="password" name="txtPassword" value="" /> (6 - 20 chars)<br/>-->
            
            <input type="submit" value="Create New Account" name="action" />
            <input type="reset" value="Reset" />
        </form>
    </body>
    </body>
</html>
