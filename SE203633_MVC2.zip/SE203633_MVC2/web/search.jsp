<%-- 
    Document   : search
    Created on : Apr 26, 2025, 8:59:02 AM
    Author     : Computing Fundamental - HCM Campus
--%>

<%--<%@page import="pe.model.registration.RegistrationDTO"%>
<%@page import="java.util.List"%> <!-- directive (page) -->--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Search</title>
    </head>
    <body>
        <font color = "red">
        Welcome, ${sessionScope.USER_INFO.fullName} <!-- wlcome cai gi thi.fullName -->
        </font>
        <!--your code here-->
        <c:url var="logoutlink" value="MainController">
            <c:param name="action" value="logout"/>
        </c:url>
        <a href="${logoutlink}">Sign Out</a>
        <h1>Search Page</h1>
        <form action="MainController">
            Search Value <input type="text" name="txtSearchValue" value="${param.txtSearchValue}" /><br/> <!-- implicit object/ scripting elements (expression) giup in gia tri va response object-->
            <input type="submit" value="Search" name="action" />
        </form><br/>

        <!-- JSTL : JSP Standard Tag Library 
        Core Taglib co 4 bo nho (General purpose, Decision Making (choose, when, otherwise), Itention, URL Related Action))-->
        <c:set var="searchValue" value="${param.txtSearchValue}" /> 
        <c:if test="${not empty searchValue}">
            <c:set var="result" value="${requestScope.SEARCH_RESULT}"/>
            <c:if test="${not empty result}"><!-- !FOUND -->
                <table border="1">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Full name</th>
                            <th>Role</th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${result}" var="regDto" varStatus="counter">
                        <form action="MainController" method="POST">
                        
                            <tr>
                                <td>
                                    ${counter.count}
                                .</td>
                                <td>
                                    ${regDto.username}
                                    <!-- binding control -->
                                    <input type="hidden" name="txtusername" value="${regDto.username}" />
                                </td>
                                <td>
                                    <input type="text" name="txtPassword" value="${regDto.password}" />
                                    
                                </td>
                                <td>
                                    ${regDto.fullName}
                                </td>
                                <td>
                                    <input type="checkbox" name="chkAdmin" value="ON" 
                                           <c:if test="${regDto.role}">
                                               checked="checked"
                                           </c:if>    
                                           />
                                </td>
                                
                                <td>
                                    <c:url var="deleteLink" value="MainController"> <!-- url related action var thi dat gi cung dc -->
                                        <c:param name="action" value="delete"/> <!--  co 3 request parameter-->
                                        <c:param name="pk" value="${regDto.username}"/> <!<!-- khoa chinh -->
                                        <c:param name="lastSearchValue" value="${searchValue}"/> <!<!--  -->
                                    </c:url>
                                        <a href="${deleteLink}">Delete</a> <!<!-- dua link vao deleteLink-->
                                </td>
                                <td>
                                    <input type="submit" value="Update" name="action" />
                                    <!-- refresh call previous function again => reminder => add more hidden controller into form => howw many controller should be add => tuong ung voi o nhap lieu o tinh nang truoc do-->
                                    <input type="hidden" name="lastSearchValue" value="${searchValue}" />
                                </td>
                            </tr>
                         </form>  
                        </c:forEach>
                    </tbody>
                </table>

            </c:if>
            <c:if test="${empty result}"><!-- !NOT FOUND -->
                <h2>
                    No record is matched!!!
                </h2>
            </c:if>
        </c:if>
        <%--
        <form action="MainController">
            Search Value <input type="text" name="txtSearchValue" value="<%= request.getParameter("txtSearchValue") %>" /><br/> <!-- implicit object/ scripting elements (expression) giup in gia tri va response object-->
            <input type="submit" value="Search" name="action" />
        </form><br/>
        <!-- scriptlets -->
        <%
            String searchValue = request.getParameter("txtSearchValue");
            if (searchValue != null){ //phai check null 
                List<RegistrationDTO> result = (List<RegistrationDTO>)request.getAttribute("SEARCH_RESULT");         //kieu object serilizable go kieu tuong minh                                   //ket qua search kieu du lieu kieu List<RegistrationDTO> nen lay ra
                if(result == null){ //check null not found
                    %>
                    <h2>
                        No record is matched!!!
                    </h2>
        <% //tach code //viet html
            }else{ //found
                %>
                <table border="1">
                    <thead>
                        <tr>
                            <th>No.</th> <!-- table header -->
                            <th>Username</th>
                            <th>Password</th>
                            <th>Full name</th>
                            <th>Role</th> 
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            int count =0; //can 1 bien dem
                            for (RegistrationDTO dto : result){
                                %>
                        <tr>
                            <td>
                                <%= ++count %> 
                                .</th>
                            <td>
                                <%= dto.getUsername() %> 
                            </td> <!-- table data -->
                            <td>
                                <%= dto.getPassword() %> 
                            </td>
                            <td>
                                <%= dto.getFullName() %> 
                            </td>
                            <td>
                                <%= dto.isRole() %> 
                            </td> 
                        </tr>
                        <%
                            }//traverse each dto in result
                        %>
                    </tbody>
                </table>

        <%
            }
            }//value is valid
        %>--%>
    </body>
</html>
