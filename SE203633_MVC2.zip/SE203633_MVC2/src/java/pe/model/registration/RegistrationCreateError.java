/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.model.registration;

import java.io.Serializable;

/**
 *
 * @author admin
 */
public class RegistrationCreateError implements Serializable{
    private String usernameOutOfRanger;
    private String passwordOutOfRanger;
    private String fullNameOutOfRanger;
    private String confirmNotMatched;

    public RegistrationCreateError() {
    }

    public String getUsernameOutOfRanger() {
        return usernameOutOfRanger;
    }

    public void setUsernameOutOfRanger(String usernameOutOfRanger) {
        this.usernameOutOfRanger = usernameOutOfRanger;
    }

    public String getPasswordOutOfRanger() {
        return passwordOutOfRanger;
    }

    public void setPasswordOutOfRanger(String passwordOutOfRanger) {
        this.passwordOutOfRanger = passwordOutOfRanger;
    }

    public String getFullNameOutOfRanger() {
        return fullNameOutOfRanger;
    }

    public void setFullNameOutOfRanger(String fullNameOutOfRanger) {
        this.fullNameOutOfRanger = fullNameOutOfRanger;
    }

    public String getConfirmNotMatched() {
        return confirmNotMatched;
    }

    public void setConfirmNotMatched(String confirmNotMatched) {
        this.confirmNotMatched = confirmNotMatched;
    }

    public String getUsernameIsExisted() {
        return usernameIsExisted;
    }

    public void setUsernameIsExisted(String usernameIsExisted) {
        this.usernameIsExisted = usernameIsExisted;
    }
    private String usernameIsExisted;
    
}
