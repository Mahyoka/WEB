/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.model.registration;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.utils.DbUtils;

/**
 *
 * @author admin
 */
public class RegistrationDAO implements Serializable {

//    public boolean checkLogin(String username, String password)
//            throws SQLException, ClassNotFoundException {
    public RegistrationDTO checkLogin(String username, String password)
            throws SQLException, ClassNotFoundException {
        RegistrationDTO result = null; //1 dau vo 1 dau ra
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            //1. Model connects to DB
            con = DbUtils.getConnection();
            if (con != null) {

                //2. Model queries data from DB
                //2.1 Create a SQL String
                String sql = " Select lastname, isAdmin " //co roi bo username
                        + "From Registration "
                        + "Where username = ? "
                        + "And password = ?";
                //2.2 Load SQL String into Statement Objetct
                stm = con.prepareStatement(sql);
                stm.setString(1, username);
                stm.setString(2, password);
                //2.3 Execute Query
                rs = stm.executeQuery();

                //3. Model gets data from DB
                if (rs.next()) {
                    //4. Model Processes to return result
//                    result = true;
                    String fullName = rs.getString("lastname");
                    boolean role = rs.getBoolean("isAdmin");
                    result = new RegistrationDTO(username, null, fullName, role);//result kieu registrationdto
                }//both username password have existed

            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return result; // 1 dau vo 1 dau ra
    }

    private List<RegistrationDTO> accounts;

    public List<RegistrationDTO> getAccounts() {
        return accounts; //dat trong list account
    }

    public void searchLastname(String searchValue) throws SQLException, ClassNotFoundException {
        //1 dau vo 1 dau ra
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            //1. Model connects to DB
            con = DbUtils.getConnection();
            if (con != null) {

                //2. Model queries data from DB
                //2.1 Create a SQL String
                String sql = "Select username, password, lastname, isAdmin \n"
                        + "From Registration "
                        + "Where lastname Like ? ";
                //2.2 Load SQL String into Statement Objetct
                stm = con.prepareStatement(sql);
                stm.setString(1, "%" + searchValue + "%"); //nay trong sql viet sao thi la vay
                //2.3 Execute Query
                rs = stm.executeQuery();

                //3. Model gets data from DB\
                //\t la phim tab giup cach ra
                while (rs.next()) {
                    //4. Model Processes and assigned values to DTO Object
                    String username = rs.getString("username");//truyen vao ten cot
                    String password = rs.getString("password");
                    String fullName = rs.getString("lastname");
                    boolean role = rs.getBoolean("isAdmin");
                    RegistrationDTO dto = new RegistrationDTO(username, password, fullName, role); //buoc 17

                    if (this.accounts == null) {
                        this.accounts = new ArrayList<>(); ///ko co thi tao
                    }//account are not available
                    this.accounts.add(dto); //co thi add vao
                }//both username password have existed

            }//connection is available
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }

    }

    public boolean deleteAccount(String username) throws SQLException, ClassNotFoundException {
        boolean result = false; //1 dau vo 1 dau ra
        Connection con = null;
        PreparedStatement stm = null;

        try {
            //1. Model connects to DB
            con = DbUtils.getConnection();
            if (con != null) {

                //2. Model queries data from DB
                //2.1 Create a SQL String
                String sql = "Delete From Registration "
                        + "Where username = ? ";
                //2.2 Load SQL String into Statement Objetct
                stm = con.prepareStatement(sql);
                stm.setString(1, username);
                //2.3 Execute Query
                int rowAffected = stm.executeUpdate(); //int vi CUD tra ve int va CUD la executeUpdate
                //3. Model gets data from DB
                if (rowAffected > 0) { //da xoa hay xoa thanh cong

                    //4. Model Processes to return result
                    result = true;
                }//deleted
                //both username password have existed
            }
        } finally {

            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return result;

    }

    public boolean createAccount(RegistrationDTO account) throws SQLException, ClassNotFoundException {
        boolean result = false; //1 dau vo 1 dau ra
        Connection con = null;
        PreparedStatement stm = null;

        try {
            //1. Model connects to DB
            con = DbUtils.getConnection();
            if (con != null) {

                //2. Model queries data from DB
                //2.1 Create a SQL String
                String sql = "Insert Into Registration( "
                        + "username, password, lastname, isAdmin "
                        + ") Values( "
                        + "?, ?, ?, ? "
                        + ")";
                //2.2 Load SQL String into Statement Objetct
                stm = con.prepareStatement(sql);
                stm.setString(1, account.getUsername());
                stm.setString(2, account.getPassword());
                stm.setString(3, account.getFullName());
                stm.setBoolean(4, account.isRole());
                //2.3 Execute Query
                int rowAffected = stm.executeUpdate(); //int vi CUD tra ve int va CUD la executeUpdate
                //3. Model gets data from DB
                if (rowAffected > 0) { //da xoa hay xoa thanh cong

                    //4. Model Processes to return result
                    result = true;
                }//deleted
                //both username password have existed
            }
        } finally {

            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return result;

    }

    public boolean updateAccount(RegistrationDTO account)
            throws SQLException, ClassNotFoundException {
        boolean result = false;
        Connection con = null;
        PreparedStatement stm = null;
        try {
            con = DbUtils.getConnection();
            if (con != null) {
                String sql = "Update Registration "
                        + "Set password = ?, isAdmin = ? "
                        + "Where username = ?";
                stm = con.prepareStatement(sql);
                // Lấy trực tiếp từ DTO ra
                stm.setString(1, account.getPassword());
                stm.setBoolean(2, account.isRole());
                stm.setString(3, account.getUsername());

                int rowAffected = stm.executeUpdate();
                if (rowAffected > 0) {
                    result = true;
                }
            }
        } finally {
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return result;
    }
}
