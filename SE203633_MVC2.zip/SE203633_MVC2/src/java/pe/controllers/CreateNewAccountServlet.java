/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package pe.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pe.model.registration.RegistrationCreateError;
import pe.model.registration.RegistrationDAO;
import pe.model.registration.RegistrationDTO;

/**
 *
 * @author admin
 */
@WebServlet(name = "CreateNewAccountServlet", urlPatterns = {"/CreateNewAccountServlet"})
public class CreateNewAccountServlet extends HttpServlet {
    private static final String ERROR_PAGE = "createAccount.jsp";
    private static final String LOGIN_PAGE = "login.html";
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = ERROR_PAGE;
        //1.Controller gets all userinformation
        String username = request.getParameter("txtUsername");
        String password = request.getParameter("txtPassword");
        String confirm = request.getParameter("txtConfirm");
        String fullName = request.getParameter("txtFullName");
        boolean foundErr = false;
        RegistrationCreateError errors = new RegistrationCreateError();
        
        try {
            //1.validation - User errors
            if(username.trim().length() <6 || username.trim().length() >30){
                foundErr = true;
                errors.setUsernameOutOfRanger("Username must be typed from 6 to 30 characters");
            }
            if(password.trim().length() < 6 || password.trim().length() > 20){
                foundErr = true;
                errors.setPasswordOutOfRanger("Password must be typed from 6 to 20 characters");
            } else if (!confirm.trim().equals(password.trim())){
                foundErr = true;
                errors.setConfirmNotMatched("Confirm password is notmatched");
            }
            if(fullName.trim().length() < 6 || fullName.trim().length() > 20){
                foundErr = true;
                errors.setFullNameOutOfRanger("Full Name must be typed from 2 to 250 characters");
            }
            if (foundErr == true){//have errors
                //store in attribute
                request.setAttribute("CREATE_ERROR", errors);
                //then show
            }else{//no error
                
            
           //2.Controller calls methods of model
           //2.1.Controller initializers a DAO Object
           RegistrationDAO dao = new RegistrationDAO();
           //2.2. Controller calls metods of DAO Object
           RegistrationDTO account = new RegistrationDTO(username, password, fullName, false);
           boolean result = dao.createAccount(account);
           if(result == true){//create account success
               url = LOGIN_PAGE;
           }//inserted
           //3.Controller processes result
            } 
        } catch(SQLException ex){
            String msg = ex.getMessage();
            log("CreateNewAccountServlet _ SQL" + ex.getMessage());
            if(msg.contains("duplicate")){
                errors.setUsernameIsExisted(username + "is existed");
                request.setAttribute("CREATE_ERROR", errors);
            }
        } catch(ClassNotFoundException ex){
            log("CreateNewAccountServlet _ ClassNotFound" + ex.getMessage());
        }
        finally{
            RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
