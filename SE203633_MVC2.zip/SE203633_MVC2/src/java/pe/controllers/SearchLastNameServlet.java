/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package pe.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pe.model.registration.RegistrationDAO;
import pe.model.registration.RegistrationDTO;

/**
 *
 * @author admin
 */
@WebServlet(name = "SearchLastNameController", urlPatterns = {"/SearchLastNameController"}) //la servet-name va url-pattern
public class SearchLastNameServlet extends HttpServlet { //servlet-class

    private static final String SEARCH_PAGE = "Search.html";
    private static final String RESULT_PAGE = "search.jsp";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = SEARCH_PAGE; //default value ko ra thi load lai Seach.html

        //1. Controller gets all user's information
        String searchValue = request.getParameter("txtSearchValue");
        try {
            if (searchValue.trim().length() > 0) {
                /* TODO output your page here. You may use following sample code. */
                //2.controller calls methods of Model
                //2.1.Controller initializes DAO object
                RegistrationDAO dao = new RegistrationDAO();
                //2.2. Controller calls methods of DAO object
                dao.searchLastname(searchValue);
                //3. Controller processes result
                List<RegistrationDTO> result = dao.getAccounts();
                request.setAttribute("SEARCH_RESULT", result);
                url = RESULT_PAGE; 
//                //demo wirshop 3
//                if(result==null){ //ko tim thay not found
//                    System.out.println("No record is matched!!!!!");
//                } else{//found
//                    System.out.println("No.\t Username\t\t Password \t\t Full Name \t\t Role");
//                    int count = 0; //de in thi ta phai khai bao 1 bien dem
//                    for(RegistrationDTO dto: result){
//                        System.out.println(++count //tang truoc khi dem
//                                + ".\t "
//                                        + dto.getUsername() //moi phan tu trong list kieu dto
//                                        + "\t\t "
//                                                + dto.getPassword()
//                                                + " \t\t "
//                                                        + dto.getFullName()
//                                                        + " \t\t "
//                                                                + dto.isRole());
//                    }//traverse each dto in result
//                    
//                } //found
            } //user types a valid value
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } finally {
            RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response); //nay de quay ve
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
