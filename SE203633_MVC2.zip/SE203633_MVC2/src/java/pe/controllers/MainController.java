/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Computing Fundamental - HCM Campus
 */
public class MainController extends HttpServlet {

//    private static final String WELCOME="login.jsp";
    private static final String WELCOME = "login.html";
    private static final String LOGIN_CONTROLLER = "LoginServlet";
    private static final String SEARCH_LASTNAME_CONTROLLER = "SearchLastNameController";
    private static final String DELETE_ACCOUNT_CONTROLLER = "DeleteAccountController";
    private static final String CREATE_NEW_ACCOUNT_CONTROLLER = "CreateNewAccountServlet";
    private static final String UPDATE_ACCOUNT_CONTROLLER = "UpdateAccountServlet";
    private static final String LOGOUT_CONTROLLER = "LogoutServlet";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = WELCOME;
        try {
            String action = request.getParameter("action");//which button
            //-----            your code here   --------------------------------
            if (action == null) { //first quest do la request parameter MainController trong web.xml trong welcome file nen action=null

            } else if (action.equals("Login")) {
                url = LOGIN_CONTROLLER;
            } else {
                //get currunt session to check
                HttpSession session = request.getSession(false);
                if (session != null) {
                    switch (action) {
                        case "Search":
                            url = SEARCH_LASTNAME_CONTROLLER;
                            break;
                        case "delete":
                            url = DELETE_ACCOUNT_CONTROLLER;
                            break;
                        case "Create New Account":
                            url = CREATE_NEW_ACCOUNT_CONTROLLER;
                            break;
                        case "Update":
                            url = UPDATE_ACCOUNT_CONTROLLER;
                            break;
                        case "logout":
                            url = LOGOUT_CONTROLLER;
                            break;
                    }// session has existed
                }
            }
            //-----            your code here   --------------------------------
        } catch (Exception e) {
            log("error at MainController: " + e.toString());
        } finally {
            RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
